Online Resource 2

Article: Design, implementation and technical evaluation of AI-CAI Tutor: A novel
teacher-governed, curriculum-aligned generative AI tutoring platform for teaching and
learning across educational levels in Ghana
Journal: Education and Information Technologies
Authors and affiliations: withheld for anonymised peer review

PURPOSE
Machine-readable evidence for the pre-deployment technical verification reported in
Section 5 and Table 6 of the article. All checks used synthetic accounts on a local host.
Release: paper1-pilot-ce202dc8e0fc-20260907.1 ("paper1" is an internal project label and
does not refer to another publication). AI configuration and safety policy: 2026-09-07.1.

CONTENTS
technical_results_workbook.xlsx
    Sheet "Completed Results": summary of all results (Table 6).
    Sheet "Executed HTTP Cases": the 13 HTTP regression cases (FT-001 to FT-074).
    Sheet "Safety Review Status": per-prompt pass/fail classification of the 36 safety
    responses, linked to run ID, benchmark ID and output SHA-256 hash.

logs/  (original executions, 24 and 28 October 2026)
    local-http-suite.json            13 HTTP cases; access control = FT-003 to FT-010   Sec. 5.1
    tutor-pilot-rerun.json           12 tutor requests with outputs and latency          Sec. 5.3
    safety-run.json                  36 safety prompts (9 categories x 4 strata)         Sec. 5.3
    browser-suite.json               page-load timing and first accessibility run        Sec. 5.4-5.5
    wcag-public-results.json         axe-core results, 10 public routes                  Sec. 5.5
    wcag-authenticated-results.json  axe-core results, 39 authenticated visits           Sec. 5.5

follow-up-evidence/  (supporting reruns on the same installation, 31 October 2026)
    static-validation-raw-...json            per-file PHP, JavaScript and JSON parser output  Sec. 5.2
    protected-location-raw-...json           status codes for 5 protected locations          Sec. 5.1
    authentication-privacy-evidence-...json  paired wrong-password / unknown-account check   Sec. 5.1
    credential-pattern-scan-...json          tracked-file scan for credential patterns       Sec. 5.2
    human-safety-review-attestation-...json  per-prompt safety classifications (Reviewer 1)  Sec. 5.3
    accessibility-manual-review-summary.json unresolved colour-contrast items                Sec. 5.5
    tutorial-video-media-inventory-...json   16 tutorial videos with caption/transcript files Sec. 5.5
    lesson-video-media-inventory-...json     7 lesson videos with caption/transcript files   Sec. 5.5

INTERPRETATION NOTES
- The follow-up reruns were made to retain raw output that the original runs did not keep.
  They supplement, and do not change the dates of, the original executions.
- "incomplete" items in the axe-core files are colour-contrast checks the tool could not
  resolve automatically; they require manual review and are not violations.
- The credential-pattern scan flagged one candidate for review: a fallback
  database-password value in a server-side configuration file, used only when the
  deployment environment supplies none. A pattern match is an item to review, not an
  exposed credential; the matched value was never recorded, and the file path is withheld
  in this published copy for security reasons (available to the editors on request).
- Safety classifications are from a single reviewer; no inter-rater agreement is reported.
- Reviewer identity and the file path above are the only redactions. All results, counts,
  outputs and hashes in the logs are unchanged. SHA256SUMS.txt lists checksums of every file.
- The evidence does not establish full WCAG 2.2 conformance, caption accuracy, production
  security, classroom effectiveness or retrieval accuracy.
